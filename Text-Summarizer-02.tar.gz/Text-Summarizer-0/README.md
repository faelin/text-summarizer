# text-summarizer
Text auto-summarizer, highlights important words and phrases